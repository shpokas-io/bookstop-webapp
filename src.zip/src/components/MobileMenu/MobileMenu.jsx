import MenuContainer from "./MenuContainer";
import PropTypes from "prop-types";

export default function MobileMenu({ isMenuOpen, toggleMenu }) {
  return <MenuContainer isMenuOpen={isMenuOpen} toggleMenu={toggleMenu} />;
}

MobileMenu.propTypes = {
  isMenuOpen: PropTypes.bool.isRequired,
  toggleMenu: PropTypes.func.isRequired,
};
