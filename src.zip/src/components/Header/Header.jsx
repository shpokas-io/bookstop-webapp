import { useState } from "react";
import ToggleButton from "../ui/ToggleButton";
import Overlay from "../ui/Overlay";
import MobileMenu from "../MobileMenu/MobileMenu";
import NavigationLinks from "./NavigationLinks";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-blue-600 text-white p-4 flex justify-between items-center">
      <h1 className="text-xl font bold">
        <a href="/">BookSpot</a>
      </h1>

      <ToggleButton onClick={toggleMenu} />
      <NavigationLinks />
      <MobileMenu isMenuOpen={isMenuOpen} toggleMenu={toggleMenu} />

      {isMenuOpen && <Overlay onClick={toggleMenu} />}
    </header>
  );
}
