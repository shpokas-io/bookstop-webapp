export default function NavigationLinks() {
  return (
    <nav className="hidden lg:flex space-x-4">
      <a href="/" className="hover:underline">
        Home
      </a>
      <a href="/reservations" className="hover:underline">
        Reservations
      </a>
    </nav>
  );
}
