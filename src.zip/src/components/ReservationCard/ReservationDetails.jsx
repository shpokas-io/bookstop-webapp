import PropTypes from "prop-types";

export default function ReservationDetails({ reservation }) {
  return (
    <>
      <h2 className="text-xl font-bold">{reservation.bookName}</h2>
      <p className="text-gray-500">Days: {reservation.days}</p>
      <p className="text-gray-500">
        Is Audiobook: {reservation.isAudiobook ? "Yes" : "No"}
      </p>
      <p className="text-gray-500">
        Quick Pickup: {reservation.isQuickPickUp ? "Yes" : "No"}
      </p>
      <p className="text-gray-500">
        Total cost: €{reservation.totalCost.toFixed(2)}
      </p>
    </>
  );
}

ReservationDetails.propTypes = {
  reservation: PropTypes.shape({
    bookName: PropTypes.string.isRequired,
    days: PropTypes.number.isRequired,
    isAudiobook: PropTypes.bool.isRequired,
    isQuickPickUp: PropTypes.bool.isRequired,
    totalCost: PropTypes.number.isRequired,
  }).isRequired,
};
