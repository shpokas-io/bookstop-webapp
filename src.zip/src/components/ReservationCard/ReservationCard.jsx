import PropTypes from "prop-types";
import BookImage from "./BookImage";
import ReservationDetails from "./ReservationDetails";
import RemoveButton from "./RemoveButton";

export default function ReservationCard({ reservation, onRemove }) {
  return (
    <div className="bg-white shadow-md rounded-lg p-4 flex flex-col items-center">
      <BookImage
        bookPictureUrl={reservation.bookPictureUrl}
        bookName={reservation.bookName}
      />
      <ReservationDetails reservation={reservation} />
      <RemoveButton onRemove={onRemove} />
    </div>
  );
}

ReservationCard.propTypes = {
  reservation: PropTypes.shape({
    bookPictureUrl: PropTypes.string.isRequired,
    bookName: PropTypes.string.isRequired,
    days: PropTypes.number.isRequired,
    isAudiobook: PropTypes.bool.isRequired,
    isQuickPickUp: PropTypes.bool.isRequired,
    totalCost: PropTypes.number.isRequired,
  }).isRequired,
  onRemove: PropTypes.func.isRequired,
};
