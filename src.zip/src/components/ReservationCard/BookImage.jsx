import PropTypes from "prop-types";

export default function BookImage({ bookPictureUrl, bookName }) {
  return (
    <img
      src={bookPictureUrl}
      alt={bookName}
      className="w-32 h-48 object-cover mb-4"
    />
  );
}

BookImage.propTypes = {
  bookPictureUrl: PropTypes.string.isRequired,
  bookName: PropTypes.string.isRequired,
};
