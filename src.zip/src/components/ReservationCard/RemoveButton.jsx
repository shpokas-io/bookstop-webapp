import PropTypes from "prop-types";

export default function RemoveButton({ onRemove }) {
  return (
    <button
      onClick={onRemove}
      className="mt-4 bg-red-500 text-white py-2 px-4 rounded"
    >
      Remove reservation
    </button>
  );
}

RemoveButton.propTypes = {
  onRemove: PropTypes.func.isRequired,
};
