export default function PricingDetails() {
  return (
    <div className="mb-4">
      <h4 className="font-bold">Pricing details:</h4>
      <ul>
        <li>Book (1 day): 2€</li>
        <li>Audiobook (1 day): 3€</li>
        <li>Service Fee: 3€</li>
        <li>Quick Pickup: 5€</li>
        <li>Total price -{">"} ReservationPage</li>
      </ul>
    </div>
  );
}
