import PropTypes from "prop-types";

export default function DurationInput({ selectedDuration, onDurationChange }) {
  return (
    <div className="mb-4">
      <label>Duration (days):</label>
      <input
        type="number"
        value={selectedDuration}
        onChange={onDurationChange}
        min="1"
        className="ml-2 border border-gray-300 rounded w-16"
      />
    </div>
  );
}

DurationInput.propTypes = {
  selectedDuration: PropTypes.number.isRequired,
  onDurationChange: PropTypes.func.isRequired,
};
