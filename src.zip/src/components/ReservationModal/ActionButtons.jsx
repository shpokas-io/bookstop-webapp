import PropTypes from "prop-types";

export default function ActionButtons({ onClose, onReserve }) {
  return (
    <div className="flex justify-between">
      <button onClick={onClose} className="bg-red-500 text-white p-2 rounded">
        Cancel
      </button>
      <button
        onClick={onReserve}
        className="bg-blue-500 text-white p-2 rounded"
      >
        Reserve
      </button>
    </div>
  );
}

ActionButtons.propTypes = {
  onClose: PropTypes.func.isRequired,
  onReserve: PropTypes.func.isRequired,
};
