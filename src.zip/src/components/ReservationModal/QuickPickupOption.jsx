import PropTypes from "prop-types";

export default function QuickPickupOption({
  selectedQuickPickup,
  onQuickPickupChange,
}) {
  return (
    <div className="mb-4">
      <label>
        Quick Pickup:
        <input
          type="checkbox"
          checked={selectedQuickPickup}
          onChange={onQuickPickupChange}
          className="ml-2"
        />
      </label>
    </div>
  );
}

QuickPickupOption.propTypes = {
  selectedQuickPickup: PropTypes.bool.isRequired,
  onQuickPickupChange: PropTypes.func.isRequired,
};
