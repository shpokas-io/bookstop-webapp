import PropTypes from "prop-types";

export default function BookTypeSelect({ selectedType, onTypeChange }) {
  return (
    <div className="mb-4">
      <label>Type:</label>
      <select
        value={selectedType}
        onChange={onTypeChange}
        className="ml-2 border border-gray-300 rounded"
      >
        <option value="Book">Book</option>
        <option value="Audiobook">Audiobook</option>
      </select>
    </div>
  );
}

BookTypeSelect.propTypes = {
  selectedType: PropTypes.string.isRequired,
  onTypeChange: PropTypes.func.isRequired,
};
