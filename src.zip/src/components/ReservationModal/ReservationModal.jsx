import PropTypes from "prop-types";
import { useState } from "react";
import BookTypeSelect from "./BookTypeSelect";
import DurationInput from "./DurationInput";
import QuickPickupOption from "./QuickPickupOption";
import PricingDetails from "./PricingDetails";
import ActionButtons from "./ActionButtons";

export default function ReservationModal({ selectedBook, onClose, onReserve }) {
  const [selectedType, setSelectedType] = useState("Book");
  const [selectedDuration, setSelectedDuration] = useState(1);
  const [selectedQuickPickup, setSelectedQuickPickup] = useState(false);

  const handleReserveClick = () => {
    const reservationData = {
      bookId: selectedBook.id,
      userId: "123",
      isAudiobook: selectedType === "Audiobook",
      days: selectedDuration,
      isQuickPickUp: selectedQuickPickup,
      bookName: selectedBook.name,
      bookPictureUrl: selectedBook.pictureUrl,
    };

    onReserve(reservationData);
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96">
        <h3 className="text-xl mb-4 font-bold">{selectedBook.name}</h3>

        <BookTypeSelect
          selectedType={selectedType}
          onTypeChange={(e) => setSelectedType(e.target.value)}
        />

        <DurationInput
          selectedDuration={selectedDuration}
          onDurationChange={(e) => setSelectedDuration(Number(e.target.value))}
        />

        <QuickPickupOption
          selectedQuickPickup={selectedQuickPickup}
          onQuickPickupChange={(e) => setSelectedQuickPickup(e.target.value)}
        />

        <PricingDetails />

        <ActionButtons onClose={onClose} onReserve={handleReserveClick} />
      </div>
    </div>
  );
}

ReservationModal.propTypes = {
  selectedBook: PropTypes.object.isRequired,
  onClose: PropTypes.func.isRequired,
  onReserve: PropTypes.func.isRequired,
};
